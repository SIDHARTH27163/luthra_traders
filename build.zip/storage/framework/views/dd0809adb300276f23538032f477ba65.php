<?php $__env->startSection('content'); ?>
<div class="p-4  rounded-lg  border-2 border-slate-900 border-dashed h-auto">
    <div class="grid grid-cols-3 gap-4 mb-4">
       <div class="flex items-center justify-center h-24 rounded  bg-rose-600">
          <p class="text-2xl text-gray-400 ">
             Luthra Traders
          </p>
       </div>
       <div class="flex items-center justify-center h-24 rounded  bg-orange-600">
          <p class="text-2xl text-gray-400 ">
             Luthra Traders
          </p>
       </div>
       <div class="flex items-center justify-center h-24 rounded  bg-green-600">
          <p class="text-2xl text-gray-400 ">
             Luthra Traders
          </p>
       </div>







    </div>

    <div class="w-full p-4 ">

   
      <div class="h-full  w-full  flex flex-col  items-center justify-center ">
        
        <div class="flex items-start  w-full justify-start">

         <?php if(session()->has('success')): ?>



        <div id="alert-1" class="flex items-center w-full p-4 mb-4 text-blue-800 rounded-lg bg-blue-50 dark:bg-gray-800 dark:text-blue-400" role="alert">
            <svg class="flex-shrink-0 w-4 h-4" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20">
              <path d="M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5ZM9.5 4a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3ZM12 15H8a1 1 0 0 1 0-2h1v-3H8a1 1 0 0 1 0-2h2a1 1 0 0 1 1 1v4h1a1 1 0 0 1 0 2Z"/>
            </svg>
            <span class="sr-only">Info</span>
            <div class="ml-3 text-sm font-medium">
                WOHOO <a href="#" class="font-semibold underline hover:no-underline"><?php echo e(session()->get('success')); ?></a>.
              </div>
              <button type="button" class="ml-auto -mx-1.5 -my-1.5 bg-blue-50 text-blue-500 rounded-lg focus:ring-2 focus:ring-blue-400 p-1.5 hover:bg-blue-200 inline-flex items-center justify-center h-8 w-8 dark:bg-gray-800 dark:text-blue-400 dark:hover:bg-gray-700" data-dismiss-target="#alert-1" aria-label="Close">
                <span class="sr-only">Close</span>
                <svg class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 14">
                  <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"/>
                </svg>
            </button>
          </div>
         <?php endif; ?>
         
         <?php if(session()->has('message')): ?>


        <div id="alert-1" class="flex items-center w-full p-4 mb-4 text-red-800 rounded-lg bg-red-50 dark:bg-gray-800 dark:text-blue-400" role="alert">
            <svg class="flex-shrink-0 w-4 h-4" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20">
              <path d="M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5ZM9.5 4a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3ZM12 15H8a1 1 0 0 1 0-2h1v-3H8a1 1 0 0 1 0-2h2a1 1 0 0 1 1 1v4h1a1 1 0 0 1 0 2Z"/>
            </svg>
            <span class="sr-only">Info</span>
            <div class="ml-3 text-sm font-medium">
              Oops <a href="#" class="font-semibold underline hover:no-underline"><?php echo e(session()->get('message')); ?></a>.
            </div>
              <button type="button" class="ml-auto -mx-1.5 -my-1.5 bg-blue-50 text-blue-500 rounded-lg focus:ring-2 focus:ring-blue-400 p-1.5 hover:bg-blue-200 inline-flex items-center justify-center h-8 w-8 dark:bg-gray-800 dark:text-blue-400 dark:hover:bg-gray-700" data-dismiss-target="#alert-1" aria-label="Close">
                <span class="sr-only">Close</span>
                <svg class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 14">
                  <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"/>
                </svg>
            </button>
          </div>

         <?php endif; ?>
         
        </div>
       
       
       
          
      </div>
  </div>



  <div class="w-full p-4 ">

   <p class="toggleColour text-gray-900 text-2xl  font-bold underline py-2"> Review Request Waiting For Approvals</p>
   <div class="relative overflow-auto shadow-md sm:rounded-lg">
      <table class="w-full text-sm text-left text-gray-500 ">
          <thead class="text-xs text-gray-100 uppercase bg-gray-700 ">
              <tr>
                  <th scope="col" class="px-3 py-3">
                     Index
                  </th>

                  <th scope="col" class="px-3 py-3">
                     Status
                   </th>

           
                  <th scope="col" class="px-3 py-3">
                    Name
                   </th>
                  
                    
                      

                          
                               <th scope="col" class="px-3 py-3">
                               Review
                                </th>


           <th scope="col" class="px-3 py-3">
           Action
         </th>
              </tr>
          </thead>
          <tbody>

            <?php $__currentLoopData = $r_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=> $r_tata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr class=" border-b bg-gray-900 border-gray-700 text-white font-semibold">
               <th scope="row" class="px-3 py-4 font-medium  whitespace-nowrap text-white">
                  <?php echo e($i); ?>

               </th>

               <td class="px-3 py-4">
                 <?php if(  $r_tata->status == 1): ?>
                 <p class="text-green-500">Approved</p>
                <?php else: ?>
                <p class="text-red-500">Not Approved</p>


                 <?php endif; ?>
               </td>

              
               <td class="px-3 py-4">
                   <?php echo e($r_tata->name); ?>

                </td>
               
               
                <td class="px-3 py-4">
                 <?php echo e($r_tata->review); ?>

              </td>
               <td class="px-1 py-4 text-center">
                   <a href="<?php echo e(url('delete_review/'.$r_tata->id)); ?>" class="font-medium text-rose-600 dark:text-rose-500 hover:underline">Delete</a><br>

                   <a href="<?php echo e(url('change_review_status/'.$r_tata->id)); ?>" class="font-medium text-orange-400 dark:text-orange-500 hover:underline">Activate/Deactivate</a><br>

              
               </td>
           </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </tbody>
      </table>
      <div class="p-2 ">

         
      </div>
   </div>
</div>
   <div class="w-full p-4 ">

      <p class="toggleColour text-gray-900 text-2xl  font-bold underline py-2"> New Contact Requests</p>
      <div class="relative overflow-auto shadow-md sm:rounded-lg">
         <table class="w-full text-sm text-left text-gray-500 ">
             <thead class="text-xs text-gray-100 uppercase bg-gray-700 ">
                 <tr>
                     <th scope="col" class="px-3 py-3">
                        Index
                     </th>
  
                     <th scope="col" class="px-3 py-3">
                        Status
                      </th>
  
                    
                     <th scope="col" class="px-3 py-3">
                      First Name
                      </th>
                      <th scope="col" class="px-3 py-3">
                          Last Name
                          </th>
                          <th scope="col" class="px-3 py-3">
                              Email
                              </th>
  
                          
                                  <th scope="col" class="px-3 py-3">
                               message
                                   </th>
  
              <th scope="col" class="px-3 py-3">
              Action
            </th>
                 </tr>
             </thead>
             <tbody>
  
               <?php $__currentLoopData = $c_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=> $c_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  
               <tr class=" border-b bg-gray-900 border-gray-700 text-white font-semibold">
                  <th scope="row" class="px-3 py-4 font-medium  whitespace-nowrap text-white">
                     <?php echo e($i); ?>

                  </th>
  
                  <td class="px-3 py-4">
                    <?php if(  $c_data->status == 1): ?>
                    <p class="text-green-500">Approved</p>
                   <?php else: ?>
                   <p class="text-red-500">Not Approved</p>
  
  
                    <?php endif; ?>
                  </td>
  
                
                  <td class="px-3 py-4">
                      <?php echo e($c_data->fname); ?>

                   </td>
                   <td class="px-3 py-4">
                      <?php echo e($c_data->lname); ?>

                   </td>
                   <td class="px-3 py-4">
                      <?php echo e($c_data->email); ?>

                   </td>
                  
                   <td class="px-3 py-4">
                    <?php echo e($c_data->message); ?>

                 </td>
                  <td class="px-1 py-4 text-center">
                     <a href="<?php echo e(url('delete_contact_req/'.$c_data->id)); ?>" class="font-medium text-rose-600 dark:text-rose-500 hover:underline">Delete</a><br>
  
                     <a href="<?php echo e(url('change_contact_req_status/'.$c_data->id)); ?>" class="font-medium text-orange-400 dark:text-orange-500 hover:underline">Activate/Deactivate</a><br>
  
                    
  
                  </td>
              </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
             </tbody>
         </table>
         <div class="p-2 ">
  
            
         </div>
      </div>
     </div>
  

   


 <div class="w-full p-4 ">

    <p class="toggleColour text-gray-900 text-2xl  font-bold underline py-2"> Queries Waiting For Approvals</p>
    <div class="relative overflow-auto shadow-md sm:rounded-lg">
       <table class="w-full text-sm text-left text-gray-500 ">
           <thead class="text-xs text-gray-100 uppercase bg-gray-700 ">
               <tr>
                   <th scope="col" class="px-3 py-3">
                      Index
                   </th>

                   <th scope="col" class="px-3 py-3">
                      Status
                    </th>

                   <th scope="col" class="px-3 py-3">
                     Service Name
                   </th>
                   <th scope="col" class="px-3 py-3">
                    First Name
                    </th>
                    <th scope="col" class="px-3 py-3">
                        Last Name
                        </th>
                        <th scope="col" class="px-3 py-3">
                            Email
                            </th>

                            <th scope="col" class="px-3 py-3">
                                Phone
                                </th>
                                <th scope="col" class="px-3 py-3">
                                 Enquiry Description
                                 </th>


            <th scope="col" class="px-3 py-3">
            Action
          </th>
               </tr>
           </thead>
           <tbody>

             <?php $__currentLoopData = $queries_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=> $d_tata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

             <tr class=" border-b bg-gray-900 border-gray-700 text-white font-semibold">
                <th scope="row" class="px-3 py-4 font-medium  whitespace-nowrap text-white">
                   <?php echo e($i); ?>

                </th>

                <td class="px-3 py-4">
                  <?php if(  $d_tata->q_status == 1): ?>
                  <p class="text-green-500">Approved</p>
                 <?php else: ?>
                 <p class="text-red-500">Not Approved</p>


                  <?php endif; ?>
                </td>

                <td class="px-3 py-4">
                   <?php echo e($d_tata->service_name); ?>

                </td>
                <td class="px-3 py-4">
                    <?php echo e($d_tata->fname); ?>

                 </td>
                 <td class="px-3 py-4">
                    <?php echo e($d_tata->lname); ?>

                 </td>
                 <td class="px-3 py-4">
                    <?php echo e($d_tata->email); ?>

                 </td>
                 <td class="px-3 py-4">
                    <?php echo e($d_tata->phone); ?>

                 </td>
                 <td class="px-3 py-4">
                  <?php echo e($d_tata->desc); ?>

               </td>
                <td class="px-1 py-4 text-center">
                    <a href="<?php echo e(url('delete_querie/'.$d_tata->q_id)); ?>" class="font-medium text-rose-600 dark:text-rose-500 hover:underline">Delete</a><br>

                    <a href="<?php echo e(url('change_q_status/'.$d_tata->q_id)); ?>" class="font-medium text-orange-400 dark:text-orange-500 hover:underline">Activate/Deactivate</a><br>

                    <a href="<?php echo e(url('create_user/'.$d_tata->q_id)); ?>" class="font-medium text-blue-400 dark:text-blue-500 hover:underline">Create user</a><br>





                </td>
            </tr>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

           </tbody>
       </table>
       <div class="p-2 ">

          
       </div>
    </div>
</div>

<div class="w-full p-4 ">

    <p class="toggleColour text-gray-900 text-2xl  font-bold underline py-2"> Banners</p>
    <div class="relative overflow-auto shadow-md sm:rounded-lg">
       <table class="w-full text-sm text-left text-gray-500 ">
           <thead class="text-xs text-gray-100 uppercase bg-gray-700 ">
               <tr>
                   <th scope="col" class="px-3 py-3">
                      Index
                   </th>
                   
                   <th scope="col" class="px-3 py-3">
                      Status
                    </th>

                   <th scope="col" class="px-3 py-3">
                   Product Name
                   </th>
                   <th scope="col" class="px-3 py-3">
                    Discount
                    </th>
                    <th scope="col" class="px-3 py-3">
                      Image
                        </th>


            <th scope="col" class="px-3 py-3">
            Action
          </th>
               </tr>
           </thead>
           <tbody>

            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class=" border-b bg-gray-900 border-gray-700 text-white font-semibold">
                
                <th scope="row" class="px-3 py-4 font-medium  whitespace-nowrap text-white">
                   <?php echo e($data->id); ?>

                </th>
                <td class="px-3 py-4">
                  <?php if(  $data->status == 1): ?>
                  <p class="text-green-500">Active</p>
                 <?php else: ?>
                 <p class="text-red-500">Not Active</p>


                  <?php endif; ?>
                </td>

                <td class="px-3 py-4">
                   <?php echo e($data->p_name); ?>

                </td>
                <td class="px-3 py-4">
                    <?php echo e($data->discount); ?>

                 </td>
                 <td>
                    <img src="<?php echo e(asset('banner_images/'.$data->image)); ?>" style="height: 50px;width:50px;">
                 </td>
                <td class="px-1 py-4 text-center">
                   <a href="<?php echo e(url('delete_banner/'.$data->id)); ?>" class="font-medium text-rose-600 dark:text-rose-500 hover:underline">Delete</a><br>

                   <a href="<?php echo e(url('change_banner_status/'.$data->id)); ?>" class="font-medium text-orange-400 dark:text-orange-500 hover:underline">Change Status</a><br>




                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

             

           </tbody>
       </table>
       <div class="p-2 ">

          
         </div>
       </div>
    </div>
    <div class="w-full p-4 ">

      <p class="toggleColour text-gray-900 text-2xl  font-bold underline py-2">Products List</p>
      <div class="relative overflow-auto shadow-md sm:rounded-lg">
         <table class="w-full text-sm text-left text-gray-500 ">
             <thead class="text-xs text-gray-100 uppercase bg-gray-700 ">
                 <tr>
                     <th scope="col" class="px-3 py-3">
                        Index
                     </th>
                    
                     <th scope="col" class="px-3 py-3">
                      Status
                   </th>
                   <th scope="col" class="px-3 py-3">
                    Catalog
                  </th>
                   <th scope="col" class="px-3 py-3">
                   Gallery Status
                 </th>
  
  
  
              <th scope="col" class="px-3 py-3">
              Category
            </th>
            <th scope="col" class="px-3 py-3">
              Product Name
           </th>
  <th scope="col" class="px-3 py-2">
    Image
  </th>
            <th scope="col" class="px-3 py-3">
              Price
            </th>
            <th scope="col" class="px-3 py-3">
              Discount
            </th>
            <th scope="col" class="px-3 py-3 text-center">
              Action
            </th>
                 </tr>
             </thead>
             <tbody>
              <?php $__currentLoopData = $p_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=> $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  
              <tr class=" border-b bg-gray-900 border-gray-700 text-white font-semibold">
                 <th scope="row" class="px-3 py-4 font-medium  whitespace-nowrap text-white">
                    <?php echo e($i); ?>

                 </th>
  
                 <td class="px-3 py-4">
                   <?php if(  $data->status == 1): ?>
                   <p class="text-green-500">Marked Available</p>
                  <?php else: ?>
                  <p class="text-red-500">Marked Not Available</p>
  
  
                   <?php endif; ?>
                 </td>
                 <td class="px-3 py-4">
                  <?php if(  $data->catalog == 1): ?>
                  <p class="text-green-500">Added</p>
                 <?php else: ?>
                 <p class="text-red-500"> Not Added</p>
  
  
                  <?php endif; ?>
                </td>
                 <td class="px-3 py-4">
                 <?php if(  $data->gallery == 1): ?>
                 <p class="text-green-500">Uploaded</p>
                <?php else: ?>
                <p class="text-red-500">Not Uploaded</p>
  
  
                 <?php endif; ?>
               </td>
  
                 <td class="px-3 py-4">
                    <?php echo e($data->category); ?>

                 </td>
              
                 
                 
                  
                  <td class="px-3 py-4">
                     <?php echo e($data->p_name); ?>

                  </td>
                  <td>
                    <img src="<?php echo e(asset('shop_images/'.$data->image)); ?>" style="height: 50px;width:50px;">
                                         
                   </td>
                  <td class="px-3 py-4">
                      <?php echo e($data->price); ?>

                   </td>
                  <td class="px-3 py-4">
                      <?php echo e($data->discount); ?>

                   </td>
                  
                 <td class="px-1 py-4 text-center">
                     <a href="<?php echo e(url('delete_pr/'.$data->id)); ?>" class="font-medium text-rose-600 dark:text-rose-500 hover:underline">Delete</a><br>
  
                     <a href="<?php echo e(url('change_pr_status/'.$data->id)); ?>" class="font-medium text-orange-400 dark:text-orange-500 hover:underline">Activate/Deactivate</a><br>
                     
                     <a href="<?php echo e(url('upload_pr_gallery/'.$data->id)); ?>" class="font-medium text-blue-400 dark:text-blue-500 hover:underline">Upload galllery</a><br>
                     
                     <a href="<?php echo e(url('change_c_status/'.$data->id)); ?>" class="font-medium text-green-400 dark:text-green-500 hover:underline">Change Catalog Status</a><br>
                     
  
  
  
                 </td>
             </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
             </tbody>
         </table>
       
      </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Luthra_traders\resources\views/admin/index.blade.php ENDPATH**/ ?>