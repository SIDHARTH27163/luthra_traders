
<?php $__env->startSection('content'); ?>
<div class="p-4  rounded-lg  border-2 border-slate-900 border-dashed h-auto">
    

   

   <div class="w-full p-4 ">

      <p class="toggleColour text-gray-900 text-2xl  font-bold underline py-2">Manage Products For Shop</p>
      <div class="h-full  w-full  flex flex-col  items-center justify-center ">
        
        <div class="flex items-start  w-full justify-start">

         <?php if(session()->has('success')): ?>



        <div id="alert-1" class="flex items-center w-full p-4 mb-4 text-blue-800 rounded-lg bg-blue-50 dark:bg-gray-800 dark:text-blue-400" role="alert">
            <svg class="flex-shrink-0 w-4 h-4" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20">
              <path d="M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5ZM9.5 4a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3ZM12 15H8a1 1 0 0 1 0-2h1v-3H8a1 1 0 0 1 0-2h2a1 1 0 0 1 1 1v4h1a1 1 0 0 1 0 2Z"/>
            </svg>
            <span class="sr-only">Info</span>
            <div class="ml-3 text-sm font-medium">
                WOHOO <a href="#" class="font-semibold underline hover:no-underline"><?php echo e(session()->get('success')); ?></a>.
              </div>
              <button type="button" class="ml-auto -mx-1.5 -my-1.5 bg-blue-50 text-blue-500 rounded-lg focus:ring-2 focus:ring-blue-400 p-1.5 hover:bg-blue-200 inline-flex items-center justify-center h-8 w-8 dark:bg-gray-800 dark:text-blue-400 dark:hover:bg-gray-700" data-dismiss-target="#alert-1" aria-label="Close">
                <span class="sr-only">Close</span>
                <svg class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 14">
                  <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"/>
                </svg>
            </button>
          </div>
         <?php endif; ?>
         
         <?php if(session()->has('message')): ?>
                <div id="alert-1" class="flex items-center w-full p-4 mb-4 text-red-800 rounded-lg bg-red-50 dark:bg-gray-800 dark:text-blue-400" role="alert">
            <svg class="flex-shrink-0 w-4 h-4" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20">
              <path d="M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5ZM9.5 4a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3ZM12 15H8a1 1 0 0 1 0-2h1v-3H8a1 1 0 0 1 0-2h2a1 1 0 0 1 1 1v4h1a1 1 0 0 1 0 2Z"/>
            </svg>
            <span class="sr-only">Info</span>
            <div class="ml-3 text-sm font-medium">
              Oops <a href="#" class="font-semibold underline hover:no-underline"><?php echo e(session()->get('message')); ?></a>.
            </div>
              <button type="button" class="ml-auto -mx-1.5 -my-1.5 bg-blue-50 text-blue-500 rounded-lg focus:ring-2 focus:ring-blue-400 p-1.5 hover:bg-blue-200 inline-flex items-center justify-center h-8 w-8 dark:bg-gray-800 dark:text-blue-400 dark:hover:bg-gray-700" data-dismiss-target="#alert-1" aria-label="Close">
                <span class="sr-only">Close</span>
                <svg class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 14">
                  <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"/>
                </svg>
            </button>
          </div>

         <?php endif; ?>
         
        </div>
       
       
       <form action="add_product" enctype="multipart/form-data" method="post" class="w-full font-Roboto">
        <?php echo csrf_field(); ?>
        <?php echo method_field('post'); ?>
        <div class="grid lg:grid-cols-2 md:grid-cols-2 grid-cols-1 gap-2">
            <div class="mb-2">
                <label for="countries" class="block mb-2 text-lg font-bold text-gray-900 ">Select a Product Category</label>
                <select id="countries" name="category" class="bg-blue-100 border border-blue-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                  <option selected value="">Choose a category</option>
                 <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <option ><?php echo e($data->category); ?></option>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
                 
                </select>
                <?php if($errors->has('category')): ?>
                <p class="text-sm italic text-red-500 text-start font-semibold"><?php echo e($errors->first('category')); ?></p>
        <?php endif; ?>
              </div>
     
              <div class="mb-2">
                <label for="name" class="block mb-2 text-lg font-semibold text-gray-900 dark:text-white">Add Product Name</label>
                <input type="text" name="product_name" id="text" class="bg-gray-50 border border-gray-300  text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" placeholder="eg:Iphone , Samsung s21 , etc">
                <?php if($errors->has('product_name')): ?>
                <p class="text-sm italic text-red-500 text-start font-semibold"><?php echo e($errors->first('product_name')); ?></p>
    <?php endif; ?>
              </div>
             
              <div class="mb-2">
                <label for="name" class="block mb-2 text-lg font-semibold text-gray-900 dark:text-white">Add Brand Name</label>
                <input type="text" name="brand_name" id="text" class="bg-gray-50 border border-gray-300  text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" placeholder="eg:Apple , Samssung , Oppo , Vivo , etc">
                <?php if($errors->has('brand_name')): ?>
                <p class="text-sm italic text-red-500 text-start font-semibold"><?php echo e($errors->first('brand_name')); ?></p>
    <?php endif; ?>
              </div>

              <div class="mb-2">
                <label for="name" class="block mb-2 text-lg font-semibold text-gray-900 dark:text-white">Add Model Name</label>
                <input type="text" name="model_name" id="text" class="bg-gray-50 border border-gray-300  text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" placeholder="eg:Apple Iphone , Realme Narzo , etc">
                <?php if($errors->has('model_name')): ?>
                <p class="text-sm italic text-red-500 text-start font-semibold"><?php echo e($errors->first('model_name')); ?></p>
    <?php endif; ?>
              </div>
              
              <div class="mb-2">
                <label for="name" class="block mb-2 text-lg font-semibold text-gray-900 dark:text-white">Add original price</label>
                <input type="text" name="original_price" id="text" class="bg-gray-50 border border-gray-300  text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" placeholder="eg:57,000 , etc">
                <?php if($errors->has('original_price')): ?>
                <p class="text-sm italic text-red-500 text-start font-semibold"><?php echo e($errors->first('original_price')); ?></p>
    <?php endif; ?>
              </div>
              <div class="mb-2">
                <label for="name" class="block mb-2 text-lg font-semibold text-gray-900 dark:text-white">Discount Of</label>
                <input type="text" name="discount" id="text" class="bg-gray-50 border border-gray-300  text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" placeholder="eg:15%">
                <?php if($errors->has('discount')): ?>
                <p class="text-sm italic text-red-500 text-start font-semibold"><?php echo e($errors->first('discount')); ?></p>
    <?php endif; ?>
              </div>
              <div class="mb-2">
                <label for="name" class="block mb-2 text-lg font-semibold text-gray-900 dark:text-white">Emi Cost</label>
                <input type="text" name="emi_cost" id="text" class="bg-gray-50 border border-gray-300  text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" placeholder="eg:2700/month, etc">
                <?php if($errors->has('emi_cost')): ?>
                <p class="text-sm italic text-red-500 text-start font-semibold"><?php echo e($errors->first('emi_cost')); ?></p>
    <?php endif; ?>
              </div>
              <div class="mb-2">
                <label for="name" class="block mb-2 text-lg font-semibold text-gray-900 dark:text-white">Replacement Time</label>
                <input type="text" name="replacement_time" id="text" class="bg-gray-50 border border-gray-300  text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" placeholder="eg:1Month ,  1 week">
                <?php if($errors->has('replacement_time')): ?>
                <p class="text-sm italic text-red-500 text-start font-semibold"><?php echo e($errors->first('replacement_time')); ?></p>
    <?php endif; ?>
              </div>
              <div class="mb-2">
                <label for="name" class="block mb-2 text-lg font-semibold text-gray-900 dark:text-white">Product Image</label>
                <input type="file" name="image" id="text" class="bg-gray-50 border border-gray-300  text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" placeholder="eg:1Month ,  1 week">
                <?php if($errors->has('image')): ?>
                <p class="text-sm italic text-red-500 text-start font-semibold"><?php echo e($errors->first('image')); ?></p>
    <?php endif; ?>
              </div>
              <div class="mb-2">
                <label for="name" class="block mb-2 text-lg font-semibold text-gray-900 dark:text-white">Warranty Policy</label>
                <select id="countries" name="warranty_policy" class="bg-blue-100 border border-blue-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                    <option selected value="">Choose one</option>
                   
                    <option >Available</option>
                    <option >Not Available</option>
                  
                  
                  </select>
                <?php if($errors->has('warranty_policy')): ?>
                <p class="text-sm italic text-red-500 text-start font-semibold"><?php echo e($errors->first('warranty_policy')); ?></p>
    <?php endif; ?>
              </div>
        </div>

      
        <div class="mb-4">
  
           <label for="message" class="block mb-2 text-lg font-medium text-gray-900 ">Description </label>
           <textarea id="message" name="description" rows="4" class="block p-2.5 w-full text-sm text-gray-900 bg-gray-50 rounded-lg border border-gray-300 focus:ring-blue-500 focus:border-blue-500  " placeholder="Write your thoughts here..."></textarea>
           <?php if($errors->has('description')): ?>
           <p class="text-sm italic text-red-500 text-start font-semibold"><?php echo e($errors->first('description')); ?></p>
  <?php endif; ?>
                         </div>
        <div class="mb-4">
            <button class="w-auto px-4 py-3  font-bold text-white bg-gradient-to-r from-black to-blue-800 hover:from-black hover:to-blue-400
                                hover:rounded-full rounded-xl focus:outline-none focus:shadow-outline
                                hover:scale-105 duration-500 ease-in-out
                               ">
                          Add Room
                       </button>
        </div>
    </form>
          
      </div>
  </div>


   





<div class="w-full p-4 ">

    <p class="toggleColour text-gray-900 text-2xl  font-bold underline py-2">Products List</p>
    <div class="relative overflow-auto shadow-md sm:rounded-lg">
       <table class="w-full text-sm text-left text-gray-500 ">
           <thead class="text-xs text-gray-100 uppercase bg-gray-700 ">
               <tr>
                   <th scope="col" class="px-3 py-3">
                      Index
                   </th>
                  
                   <th scope="col" class="px-3 py-3">
                    Status
                 </th>
                 <th scope="col" class="px-3 py-3">
                  Catalog
                </th>
                 <th scope="col" class="px-3 py-3">
                 Gallery Status
               </th>



            <th scope="col" class="px-3 py-3">
            Category
          </th>
          <th scope="col" class="px-3 py-3">
            Product Name
         </th>
<th scope="col" class="px-3 py-2">
  Image
</th>
          <th scope="col" class="px-3 py-3">
            Price
          </th>
          <th scope="col" class="px-3 py-3">
            Discount
          </th>
          <th scope="col" class="px-3 py-3 text-center">
            Action
          </th>
               </tr>
           </thead>
           <tbody>
            <?php $__currentLoopData = $p_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=> $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr class=" border-b bg-gray-900 border-gray-700 text-white font-semibold">
               <th scope="row" class="px-3 py-4 font-medium  whitespace-nowrap text-white">
                  <?php echo e($i); ?>

               </th>

               <td class="px-3 py-4">
                 <?php if(  $data->status == 1): ?>
                 <p class="text-green-500">Marked Available</p>
                <?php else: ?>
                <p class="text-red-500">Marked Not Available</p>


                 <?php endif; ?>
               </td>
               <td class="px-3 py-4">
                <?php if(  $data->catalog == 1): ?>
                <p class="text-green-500">Added</p>
               <?php else: ?>
               <p class="text-red-500"> Not Added</p>


                <?php endif; ?>
              </td>
               <td class="px-3 py-4">
               <?php if(  $data->gallery == 1): ?>
               <p class="text-green-500">Uploaded</p>
              <?php else: ?>
              <p class="text-red-500">Not Uploaded</p>


               <?php endif; ?>
             </td>

               <td class="px-3 py-4">
                  <?php echo e($data->category); ?>

               </td>
            
               
               
                
                <td class="px-3 py-4">
                   <?php echo e($data->p_name); ?>

                </td>
                <td>
                  <img src="<?php echo e(asset('shop_images/'.$data->image)); ?>" style="height: 50px;width:40px;">
                                       
                 </td>
                <td class="px-3 py-4">
                    <?php echo e($data->price); ?>

                 </td>
                <td class="px-3 py-4">
                    <?php echo e($data->discount); ?>

                 </td>
                
               <td class="px-1 py-4 text-center">
                   <a href="<?php echo e(url('delete_pr/'.$data->id)); ?>" class="font-medium text-rose-600 dark:text-rose-500 hover:underline">Delete</a><br>

                   <a href="<?php echo e(url('change_pr_status/'.$data->id)); ?>" class="font-medium text-orange-400 dark:text-orange-500 hover:underline">Activate/Deactivate</a><br>
                   
                   <a href="<?php echo e(url('upload_pr_gallery/'.$data->id)); ?>" class="font-medium text-blue-400 dark:text-blue-500 hover:underline">Upload galllery</a><br>
                   
                   <a href="<?php echo e(url('change_c_status/'.$data->id)); ?>" class="font-medium text-green-400 dark:text-green-500 hover:underline">Change Catalog Status</a><br>
                   
                   <a href="<?php echo e(url('edit_pr/'.$data->id)); ?>" class="font-medium text-yellow-400 dark:text-yellow-500 hover:underline">Edit Product</a><br>
                   



               </td>
           </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
           </tbody>
       </table>
     
    </div>
</div>


</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Luthra_traders\resources\views/admin/manage_products.blade.php ENDPATH**/ ?>