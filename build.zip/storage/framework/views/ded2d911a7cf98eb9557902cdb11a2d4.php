
<?php $__env->startSection('content'); ?>
<div class="p-4  rounded-lg  border-2 border-slate-900 border-dashed h-auto">
    

   

   <div class="w-full p-4 ">

      <p class="toggleColour text-gray-900 text-2xl  font-bold underline py-2">Manage Categories For Shop</p>
      <div class="h-full  w-full  flex flex-col  items-center justify-center ">
        
        <div class="flex items-start  w-full justify-start">

         <?php if(session()->has('success')): ?>



        <div id="alert-1" class="flex items-center w-full p-4 mb-4 text-blue-800 rounded-lg bg-blue-50 dark:bg-gray-800 dark:text-blue-400" role="alert">
            <svg class="flex-shrink-0 w-4 h-4" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20">
              <path d="M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5ZM9.5 4a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3ZM12 15H8a1 1 0 0 1 0-2h1v-3H8a1 1 0 0 1 0-2h2a1 1 0 0 1 1 1v4h1a1 1 0 0 1 0 2Z"/>
            </svg>
            <span class="sr-only">Info</span>
            <div class="ml-3 text-sm font-medium">
                WOHOO <a href="#" class="font-semibold underline hover:no-underline"><?php echo e(session()->get('success')); ?></a>.
              </div>
              <button type="button" class="ml-auto -mx-1.5 -my-1.5 bg-blue-50 text-blue-500 rounded-lg focus:ring-2 focus:ring-blue-400 p-1.5 hover:bg-blue-200 inline-flex items-center justify-center h-8 w-8 dark:bg-gray-800 dark:text-blue-400 dark:hover:bg-gray-700" data-dismiss-target="#alert-1" aria-label="Close">
                <span class="sr-only">Close</span>
                <svg class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 14">
                  <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"/>
                </svg>
            </button>
          </div>
         <?php endif; ?>
         
         <?php if(session()->has('message')): ?>
                <div id="alert-1" class="flex items-center w-full p-4 mb-4 text-red-800 rounded-lg bg-red-50 dark:bg-gray-800 dark:text-blue-400" role="alert">
            <svg class="flex-shrink-0 w-4 h-4" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20">
              <path d="M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5ZM9.5 4a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3ZM12 15H8a1 1 0 0 1 0-2h1v-3H8a1 1 0 0 1 0-2h2a1 1 0 0 1 1 1v4h1a1 1 0 0 1 0 2Z"/>
            </svg>
            <span class="sr-only">Info</span>
            <div class="ml-3 text-sm font-medium">
              Oops <a href="#" class="font-semibold underline hover:no-underline"><?php echo e(session()->get('message')); ?></a>.
            </div>
              <button type="button" class="ml-auto -mx-1.5 -my-1.5 bg-blue-50 text-blue-500 rounded-lg focus:ring-2 focus:ring-blue-400 p-1.5 hover:bg-blue-200 inline-flex items-center justify-center h-8 w-8 dark:bg-gray-800 dark:text-blue-400 dark:hover:bg-gray-700" data-dismiss-target="#alert-1" aria-label="Close">
                <span class="sr-only">Close</span>
                <svg class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 14">
                  <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"/>
                </svg>
            </button>
          </div>

         <?php endif; ?>
         
        </div>
       
       
          <form action="add_shop_cat" method="post" enctype="multipart/form-data" class="lg:w-3/4 md:w-3/4 sm:w-3/4 w-full bg-white p-4  rounded-lg shadow-lg  ">
              <?php echo csrf_field(); ?>
              <?php echo method_field('post'); ?>
              <div class="mb-4">
                <label for="name" class="block mb-2 text-lg font-medium text-gray-900 dark:text-white">Add Category</label>
                <input type="text" name="category" id="text" class="bg-gray-50 border border-gray-300  text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" placeholder="eg:Wathes , Mobiles , Accesories">
                <?php if($errors->has('category')): ?>
                <p class="text-sm italic text-red-500 text-start font-semibold"><?php echo e($errors->first('category')); ?></p>
    <?php endif; ?>
              </div>
              <div class="mb-4">
                <label for="name" class="block mb-2 text-lg font-medium text-gray-900 dark:text-white">Add Category Image</label>
                <input type="file" name="image" id="text" class="bg-gray-50 border border-gray-300  text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" placeholder="eg:Wathes , Mobiles , Accesories">
                <?php if($errors->has('image')): ?>
                <p class="text-sm italic text-red-500 text-start font-semibold"><?php echo e($errors->first('image')); ?></p>
    <?php endif; ?>
              </div>
             
              <div class="mb-4">
                  <button class="w-auto px-4 py-3  font-bold text-white bg-gradient-to-r from-black to-blue-800 hover:from-black hover:to-blue-400
                                      hover:rounded-full rounded-xl focus:outline-none focus:shadow-outline
                                      hover:scale-105 duration-500 ease-in-out
                                     ">
                                Submit
                             </button>
              </div>
          </form>
          
      </div>
  </div>


   





<div class="w-full p-4 ">

    <p class="toggleColour text-gray-900 text-2xl  font-bold underline py-2">Categories List</p>
    <div class="relative overflow-auto shadow-md sm:rounded-lg">
       <table class="w-full text-sm text-left text-gray-500 ">
           <thead class="text-xs text-gray-100 uppercase bg-gray-700 ">
               <tr>
                   <th scope="col" class="px-3 py-3">
                      Index
                   </th>
                   <th scope="col" class="px-3 py-3">
                      Id
                   </th>
                   <th scope="col" class="px-3 py-3">
                    Status
                 </th>

                   <th scope="col" class="px-3 py-3">
                    Image
                 </th>




            <th scope="col" class="px-3 py-3">
            Category
          </th>
          <th scope="col" class="px-3 py-3 text-center">
            Action
          </th>
               </tr>
           </thead>
           <tbody>

             <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=> $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

             <tr class=" border-b bg-gray-900 border-gray-700 text-white font-semibold">
                <th scope="row" class="px-3 py-4 font-medium  whitespace-nowrap text-white">
                   <?php echo e($i); ?>

                </th>
                <th scope="row" class="px-3 py-4 font-medium  whitespace-nowrap text-white">
                   <?php echo e($data->id); ?>

                </th>
                <td class="px-3 py-4">
                    <?php if(  $data->status == 1): ?>
                    <p class="text-green-500">Activated</p>
                   <?php else: ?>
                   <p class="text-red-500">De Activated</p>
                    
    
                    <?php endif; ?>
                  </td>
                <td>
                    <img src="<?php echo e(asset('shop_images/'.$data->image)); ?>" style="height: 50px;width:50px;">
                                         
                   </td>

                <td class="px-3 py-4">
                   <?php echo e($data->category); ?>

                </td>


                <td class="px-1 py-4 text-center">
                   <a href="<?php echo e(url('delete_shop_cats/'.$data->id)); ?>" class="font-bold font-Roboto text-rose-600 dark:text-rose-500 hover:underline">Delete</a><br>
                   <a href="<?php echo e(url('change_shop_cats/'.$data->id)); ?>" class="font-bold font-Roboto text-green-500  hover:underline">Activate/ Deactivate</a><br>





                </td>
            </tr>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

           </tbody>
       </table>
       <div class="p-2 ">

          
       </div>
    </div>
</div>


</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Luthra_traders\resources\views/admin/manage_shop_cat.blade.php ENDPATH**/ ?>